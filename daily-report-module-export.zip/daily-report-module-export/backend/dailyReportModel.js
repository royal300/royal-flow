const mongoose = require('mongoose');

const dailyReportSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  staffId: { type: String, required: true },
  staffName: { type: String, required: true },
  date: { type: String, required: true },
  content: { type: String, required: true },
  reportType: { type: String, default: 'general' }, // 'general' | 'creative'
  clientName: String,
  creativeType: String,
  itemCount: Number,
  createdAt: { type: String, default: () => new Date().toISOString() },
  updatedAt: { type: String, default: () => new Date().toISOString() }
}, { strict: false });

const DailyReport = mongoose.model('DailyReport', dailyReportSchema);

module.exports = { DailyReport, dailyReportSchema };
