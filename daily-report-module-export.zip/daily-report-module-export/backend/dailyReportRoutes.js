const express = require('express');
const crypto = require('crypto');
const { DailyReport } = require('./dailyReportModel');

const router = express.Router();

// GET all daily reports (sorted newest first)
router.get('/', async (req, res) => {
    try {
        const reports = await DailyReport.find().sort({ date: -1 });
        res.json(reports);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET reports by specific staff ID
router.get('/staff/:staffId', async (req, res) => {
    try {
        const reports = await DailyReport.find({ staffId: req.params.staffId }).sort({ date: -1 });
        res.json(reports);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST create a new daily report entry
router.post('/', async (req, res) => {
    try {
        const newReport = new DailyReport({
            ...req.body,
            id: crypto.randomUUID(),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        });
        await newReport.save();
        res.json(newReport);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT update an existing report by ID
router.put('/:id', async (req, res) => {
    try {
        const data = { ...req.body, updatedAt: new Date().toISOString() };
        const updated = await DailyReport.findOneAndUpdate({ id: req.params.id }, data, { new: true });
        if (!updated) {
            return res.status(404).json({ error: 'Report not found' });
        }
        res.json(updated);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE remove a report by ID
router.delete('/:id', async (req, res) => {
    try {
        await DailyReport.deleteOne({ id: req.params.id });
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
