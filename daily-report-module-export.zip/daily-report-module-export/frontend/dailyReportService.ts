export interface DailyReport {
  id: string;
  staffId: string;
  staffName: string;
  date: string;
  content: string;
  reportType?: 'general' | 'creative';
  clientName?: string;
  creativeType?: string;
  itemCount?: number;
  createdAt: string;
  updatedAt: string;
}

// Example API client wrapper assuming an Axios or Fetch instance (`api`)
// Replace `api` with your project's HTTP client or fetch wrapper.
import { api } from './api'; // Adjust import according to your project structure

export const dailyReportService = {
  async getAll(): Promise<DailyReport[]> {
    return api.get<DailyReport[]>('/daily-reports');
  },

  async getByStaffId(staffId: string): Promise<DailyReport[]> {
    const reports = await this.getAll();
    return reports.filter(r => r.staffId === staffId);
  },

  async create(report: Omit<DailyReport, 'id' | 'createdAt' | 'updatedAt'>): Promise<DailyReport> {
    return api.post<DailyReport>('/daily-reports', report);
  },

  async update(id: string, content: string, data?: Partial<DailyReport>): Promise<DailyReport> {
    return api.put<DailyReport>(`/daily-reports/${id}`, { content, ...data });
  },

  async delete(id: string): Promise<void> {
    return api.delete(`/daily-reports/${id}`);
  },
};
